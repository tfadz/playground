<?php

/**
 * Plugin Name: LH Block Styles
 * Plugin URI: https://github.com/Automattic/gutenberg-block-styles/
 * Description: A simple plugin to add block styles to Gutenberg.
 * Version: 1.0
 * Author: Lipman Hearne
 */

/**
 * Register custom blocks
 */
function my_register_blocks() {

    // check function exists.
    if( function_exists('acf_register_block_type') ) {

        // Register the CTA Row block.
        acf_register_block_type(array(
            'name'              => 'hero',
            'title'             => __('Hero'),
            'description'       => __('A hero'),
            'render_template'   => plugin_dir_path( __FILE__ ) . 'template-parts/hero.php',
            'category'          => 'common',
            'icon'              => 'button',
            'mode'              => 'auto',
        ));

    }
}

add_action('acf/init', 'my_register_blocks');



/**
 * Enqueue Block Styles Javascript
 */
// echo filemtime( plugin_dir_path( __FILE__ ) . '/block.js' );
function block_styles_enqueue_javascript() {
	wp_enqueue_script( 'block-styles-script',
		plugins_url( 'block.js', __FILE__ ),
		array( 'wp-blocks', 'wp-dom-ready', 'wp-edit-post' ),
		filemtime( plugin_dir_path( __FILE__ ) . '/block.js' )
	);
}
add_action( 'enqueue_block_editor_assets', 'block_styles_enqueue_javascript' );


/**
 * Enqueue Block Styles Stylesheet
 */
function block_styles_enqueue_stylesheet() {
	wp_enqueue_style( 'block-styles-stylesheet',
		plugins_url( 'style.css', __FILE__ ) 
	);
}
add_action( 'enqueue_block_assets', 'block_styles_enqueue_stylesheet' );

