/**
 * Declare the block you'd like to style. 
 * Duplicate and customize the four lines below for each style variation you'd like to add.
 */

wp.domReady( function() {
    wp.blocks.unregisterBlockType( 'core/button' );

	wp.blocks.registerBlockStyle( 'core/paragraph', {
		name: 'lead',
		label: 'Lead Paragraph',
	} );

});



