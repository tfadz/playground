<?php
/**
 * Template part for displaying CTA rows
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bridgwater plugin
 */

?>

<?php 
    $buttontext = get_field('button_text');
    $paneltext = get_field('panel_text');
?>


<div class="accordion-row-container">

    <div class="row justify-content-center mb-3 accordion-row">

    	<div class="col">

            <button class="btn accordion-button collapsed" data-toggle="collapse" href="#collapseExample"><?php echo $buttontext; ?></button>

            <div id="collapseExample" class="collapse accordion-panel-text"><?php echo $paneltext; ?></div>

    	</div><!-- column -->

    </div> <!-- row -->

</div> <!-- container -->