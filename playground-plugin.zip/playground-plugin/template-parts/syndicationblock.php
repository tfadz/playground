<?php
/**
 * Template part for displaying CTA rows
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bridgwater plugin
 */

?>

<?php 
    $blocktitle = get_field('headline');

?>

<h3><?php echo $blocktitle; ?></h3>

<?php

// check if the flexible content field has rows of data
if( have_rows('block_to_include') ):

     // loop through the rows of data
    while ( have_rows('block_to_include') ) : the_row();

        if( get_row_layout() == 'page' ):

        	$postobj = get_sub_field('select_a_page_or_post');
        	$postlink = $postobj->guid;
        	$post_title = $postobj->post_title;
        	echo '<br><br>';
        	echo '<a href="'.$postlink.'">' . $post_title . '</a><br>';
        	if ( strlen($postobj->post_excerpt) > 2 ) {
	        	// $post_excerpt = $postobj->post_excerpt;
        		$post_excerpt = wp_trim_words( $postobj->post_excerpt, $num_words = 50, $more = '… ' );
	        } else {
	        	$post_excerpt = wp_trim_words( $postobj->post_content, $num_words = 50, $more = '… ' );
	        }
        	echo $post_excerpt . '<br>';
        	$post_id = $postobj->ID;
        	$post_thumb = get_the_post_thumbnail($post_id, 'medium');
        	echo $post_thumb . '<br>';

        elseif( get_row_layout() == 'tweet' ): 

        	$tweet = get_sub_field('tweet');
        	$twimg = get_sub_field('image');
        	$twimgsrc = $twimg['sizes']['medium'];
        	$twalt = $twimg['alt'];
        	$twclickthrough = get_sub_field('clickthrough_destination');
        	echo '<br><br>';
        	echo '<a href="'.$twclickthrough.'">' . $tweet . '</a><br>';
        	echo '<img src="' . $twimgsrc . '" alt="' . $twalt . '">' . '<br>';

        elseif( get_row_layout() == 'instagram' ): 

        	$twimg = get_sub_field('image');
        	$twimgsrc = $twimg['sizes']['medium'];
        	$twalt = $twimg['alt'];
        	$twclickthrough = get_sub_field('clickthrough_destination');
        	echo '<br><br>';
        	echo '<a href="'.$twclickthrough.'">' . '<img src="' . $twimgsrc . '" alt="' . $twalt . '">' . '</a><br>';

        elseif( get_row_layout() == 'youtube' ): 

        	$ytlink = get_sub_field('video_url');
        	$yttitle = get_sub_field('title');
        	$ytdescription = get_sub_field('description');
        	echo '<br><br>';
        	echo $ytlink;
        	echo '<br>';
        	echo $yttitle;
        	echo '<br>';
        	echo $ytdescription;
        	echo '<br>';
        	echo '<br>';

        elseif( get_row_layout() == 'category' ): 

        	$select_a_category = get_sub_field('select_a_category');
        	$select_a_category[] = '1'; // push "uncategorized" to the end of the array in case none selected return results
        	$number_of_selected_categories = sizeof($select_a_category);
        	// echo '# selected: ' . $number_of_selected_categories;
        	for ( $i = 0; $i <  $number_of_selected_categories; $i++ ) {
				$args = array(
					'numberposts' => 1,
					'offset' => 0,
					'category' => $select_a_category[$i],
					'orderby' => 'post_date',
					'order' => 'DESC',
					'include' => '',
					'exclude' => '',
					'meta_key' => '',
					'meta_value' =>'',
					'post_type' => 'post',
					'post_status' => 'publish',
					'suppress_filters' => true
				);

				$recent_posts = wp_get_recent_posts( $args );

				if ( sizeof($recent_posts ) > 0 ) {
					foreach( $recent_posts as $recent ){
						$postlink = $recent['guid'];
						$post_title = $recent['post_title'];
						echo '<br><br>';
						echo '<a href="'.$postlink.'">' . $post_title . '</a><br>';
						if ( strlen($recent['post_excerpt']) > 2 ) {
							$post_excerpt = wp_trim_words( $recent['post_excerpt'], $num_words = 50, $more = '… ' );
						} else {
							$post_excerpt = wp_trim_words( $recent['post_content'], $num_words = 50, $more = '… ' );
						}
						echo $post_excerpt . '<br>';
						$post_id = $recent['ID'];
						$post_thumb = get_the_post_thumbnail($post_id, 'medium');
						echo $post_thumb . '<br>';						
					}

		        	// var_dump($recent_posts);
					wp_reset_query();
					break;
				}
			}

        endif;

    endwhile;

else :

    // no layouts found

endif;

?>