<?php
/**
 * Template part for displaying CTA rows
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bridgwater plugin
 */

?>

<?php 
    $blocktitle = get_field('headline');
    if ( get_field('maximum_age_for_news_stories') ) {
	    $maximum_age_for_news_stories = get_field('maximum_age_for_news_stories');
	} else {
		$maximum_age_for_news_stories = 90;
	}
	$after = $maximum_age_for_news_stories . ' days ago';

?>

<h3><?php echo $blocktitle; ?></h3>

<?php

	$topics = get_field('select_a_category');
	$topics[] = 1; // push "uncategorized" to the end of the array in case none selected return results
	// var_dump($topics);

	$topicsSlugArr = array();
	foreach($topics as $topic):
		$topic = get_category($topic);
		array_push($topicsSlugArr, $topic->slug);
	endforeach;
	// var_dump($topicsSlugArr);

	$number_of_posts_found = 0;
	$number_of_posts_wanted = 4;
	$number_of_post_to_cast_for = ($number_of_posts_wanted * 2);
	
	$relatedPostsQueryByTopic = new WP_Query( array( 	'post_type' 		=> 'post',
										'posts_per_page' 	=> $number_of_post_to_cast_for,
										// 'tax_query' => array(
										// 		'relation' => 'OR',
										// 		array(
										// 			'taxonomy' => 'category',
										// 			'field'    => 'slug',
										// 			'terms'    => $topicsSlugArr,
										// 		),
										// 	),
										'date_query' => array(
												'column' => 'post_date',
												'after'  => $after,
												// 'after' => '3 days ago',
											),
										'post__not_in' 		=> array( get_the_ID() )
	));


	if( $relatedPostsQueryByTopic->have_posts() ):
		
		while ( $relatedPostsQueryByTopic->have_posts() ) :
						
			$relatedPostsQueryByTopic->the_post();
			if ( in_category($topicsSlugArr) ):
				
				$number_of_posts_found += 1;

				include( plugin_dir_path( __FILE__ ) . 'syndicationblock_news_child.php' );

				if ( $number_of_posts_found === $number_of_posts_wanted ) {
					break;
				}

			endif;

		endwhile;

		// echo '<br><br> found ' . $number_of_posts_found . ' posts in selected categories <br><br>';
		if ( $number_of_posts_found < $number_of_posts_wanted ):
			// echo '<br><br> need ' . ($number_of_posts_wanted - $number_of_posts_found) . ' more<br><br>';

			while ( $relatedPostsQueryByTopic->have_posts() ) :
							
				$relatedPostsQueryByTopic->the_post();
				if ( !in_category($topicsSlugArr) ):
					$number_of_posts_found += 1;
					
					include( plugin_dir_path( __FILE__ ) . 'syndicationblock_news_child.php' );

					if ( $number_of_posts_found === $number_of_posts_wanted ) {
						break;
					}

				endif;

			endwhile;

		endif;	


	wp_reset_query();
	wp_reset_postdata();

	else:
		echo 'nothing found';
	endif;