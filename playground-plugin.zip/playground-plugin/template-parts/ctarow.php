<?php
/**
 * Template part for displaying CTA rows
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bridgwater plugin
 */

?>

<?php
    
    $rows = get_sub_field('button');
    $number_of_buttons = count($rows);

?>



<div class="row justify-content-center mb-3 cta-row">

	<div class="col col-md-10 col-lg-8 text-md-center">

<?php while ( have_rows('button') ) : the_row(); ?>

    <?php 
        $link = get_sub_field('link');
        	$linktext = $link['title'];
        	$href = $link['url'];
        	$target = $link['target'];

        $style = get_sub_field('primary_or_secondary_style');

        // var_dump($link);
        // var_dump($style);
    ?>
    <a href="<?php echo $href; ?>" target="<?php echo $target ?>" class="btn btn-<?php echo $style ?>">
        <?php echo $linktext ?>
    </a> 

<?php endwhile; ?>

	</div><!-- column -->

</div> <!-- row -->

