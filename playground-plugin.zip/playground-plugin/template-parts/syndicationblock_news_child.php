<?php
/**
 * Template part for displaying articles in syndication block
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Bridgwater plugin
 */

?>

<?php 
		$postdate = get_the_date();
		$postlink = get_the_permalink();
		$post_title = get_the_title();
		$post_excerpt = get_the_excerpt();
		$post_thumb = get_the_post_thumbnail(null, 'medium');
		if ( strlen($post_excerpt) > 2 ) {
			$post_excerpt = wp_trim_words( $post_excerpt, $num_words = 50, $more = '… ' );
		} else {
			$post_excerpt = wp_trim_words( get_the_content(), $num_words = 50, $more = '… ' );
		}

		echo '<br><br>';
		echo '<big>#' . $number_of_posts_found . '</big> ';
		echo 'posted on ' . $postdate;
		// echo ' in ' . $related_post_category_name;
		echo '<br>';
		echo '<a href="'.$postlink.'">' . $post_title . '</a><br>';
		echo $post_excerpt . '<br>';
		echo $post_thumb . '<br>';		