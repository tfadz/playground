<?php
/**
 * Template part for hero
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Playground plugin
 */

?>


<div class="the-hero">
  <h1><?php the_field('title'); ?></h1>
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
  <?php
    $image = get_field('image')['url'];
   ?>
  <img src="<?php echo $image ?>" alt="placeholder+image">
</div>

